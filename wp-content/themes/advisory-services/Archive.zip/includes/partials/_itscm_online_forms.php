<div class="card">
    <div class="card-body text-center">
        <img src="<?php echo IMAGE_DIR_URL.'dashboard/itscm/onine_forms.png'; ?>" class="img-responsive" style="margin: 20px auto 25px auto;">
        <!-- <div class="itscm-title"><div class="title">Online Forms</div><h6 class="sub-title"><span>Business continuity and disaster recovery</span></h6></div> -->
        <div class="itscmDashboardLogos">
            <a href="javascript:;"><img src="<?php echo IMAGE_DIR_URL.'dashboard/itscm/disaster_management_forms.png'; ?>" class="img-responsive comingSoon" alt=""></a>
            <a href="<?php echo site_url('recovery-playbook') ?>"><img src="<?php echo IMAGE_DIR_URL.'dashboard/itscm/recovery_playbook.png'; ?>" class="img-responsive" alt=""></a>
            <a href="javascript:;"><img src="<?php echo IMAGE_DIR_URL.'dashboard/itscm/tabletop_exercise_handbook.png'; ?>" class="img-responsive" alt="" data-toggle="modal" data-target="#tableTop"></a>
            <img src="<?php echo IMAGE_DIR_URL.'dashboard/itscm/allocation.png'; ?>" class="img-responsive allocationBtn orderRestoration">
        </div>
    </div>
</div>
<?php require_once P3_TEMPLATE_PATH .'/includes/modals/_order_restoration.php'; ?>