<div class="modal fade" id="noDMM">
	<div class="modal-dialog modal-sm xs">
		<div class="modal-content black" style="background-color: #000;">
			<div class="modal-body">
				<div class="text-center">
					<h5 class="text-center" style="color: #fff;">Sorry - this assessment is inactive</h5>
				    <img style="width:100px" src="<?php echo get_template_directory_uri(); ?>/images/alert1.png">
				</div>
			</div>
		</div>
	</div>
</div>